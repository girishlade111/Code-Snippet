import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import LanguageSelector from './components/LanguageSelector';
import CodeSnippetDisplay from './components/CodeSnippetDisplay';
import { languages } from './data/languages';
import { generateSnippet } from './data/snippets';
import { ThemeProvider } from './hooks/useTheme';
import { CodeSnippet } from './types';
import { MessageSquare, Terminal, Loader2 } from 'lucide-react';

function App() {
  const [selectedLanguage, setSelectedLanguage] = useState('javascript');
  const [prompt, setPrompt] = useState('');
  const [snippet, setSnippet] = useState<CodeSnippet | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    
    try {
      const generatedSnippet = await generateSnippet(prompt, selectedLanguage);
      setSnippet(generatedSnippet);
    } catch (err) {
      setError('Failed to generate snippet. Please try again.');
      console.error('Error:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      handleGenerate();
    }
  };

  return (
    <ThemeProvider>
      <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <Header />
        
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <MessageSquare className="text-indigo-600 dark:text-indigo-400" size={20} />
                Describe Your Snippet
              </h2>
              
              <textarea
                className="w-full p-3 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 focus:border-transparent bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 resize-none transition-colors duration-200"
                placeholder="Describe the code snippet you need (e.g., 'Create a React component with state' or 'JavaScript function to fetch data from an API')"
                rows={4}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={handleKeyDown}
              />
              
              <div className="mt-4 flex flex-col md:flex-row gap-4">
                <div className="w-full md:w-auto">
                  <h3 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300 flex items-center gap-1">
                    <Terminal size={16} />
                    Language / Framework
                  </h3>
                  <LanguageSelector
                    languages={languages}
                    selectedLanguage={selectedLanguage}
                    onLanguageChange={setSelectedLanguage}
                  />
                </div>
                
                <div className="flex-grow flex items-end">
                  <button
                    onClick={handleGenerate}
                    disabled={!prompt.trim() || isGenerating}
                    className={`w-full md:w-auto px-4 py-2 rounded-md font-medium flex items-center justify-center transition-colors duration-200 ${
                      !prompt.trim() || isGenerating
                        ? 'bg-gray-300 dark:bg-gray-700 cursor-not-allowed text-gray-500 dark:text-gray-400'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    }`}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 size={18} className="animate-spin mr-2" />
                        Generating...
                      </>
                    ) : (
                      'Generate Snippet'
                    )}
                  </button>
                </div>
              </div>
              
              <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                Pro tip: Press Ctrl+Enter to generate
              </div>
              
              {error && (
                <div className="mt-4 p-3 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 rounded-md">
                  {error}
                </div>
              )}
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-4">Code Snippet</h2>
              <CodeSnippetDisplay snippet={snippet} />
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </ThemeProvider>
  );
}

export default App